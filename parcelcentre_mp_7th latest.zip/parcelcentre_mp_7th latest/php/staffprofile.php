<?php
session_start(); // Start session if not already started

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    // Redirect to login page or handle unauthorized access
    header("Location: loginindex.php");
    exit;
}

// Include your database connection
require_once 'db.php'; // Adjust path as per your setup

// Fetch user details from database
$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT fullname, role, username, email FROM users WHERE user_id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Check if user exists
if (!$user) {
    // Handle scenario where user is not found
    // Redirect or display an error message
    die("User not found");
}

// Example: Display user information
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- Bootstrap Icons CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/styles.css">
    <link rel="stylesheet" href="../css/staffprofile.css">

</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light">
    <a class="navbar-brand" href="#" style="color: #F8F3EA;">
        <img src="../image/logo.jpg" alt="Logo">
        RHA Parcel Centre</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ml-auto">
        <li class="nav-item">
                <a class="nav-link" href="../php/add_parcel.php">Manage Parcels</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="../php/staffdashboard.php">Parcel Information</a>
            </li>

            <!-- User Account Section -->
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle"  href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="bi bi-person-circle"></span>
                     <!-- Replace with actual user name -->
                </a>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                    <a class="dropdown-item" href="../php/profile.php">My Profile</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="../php/loginindex.php">Logout</a>
                </div>
            </li>
        </ul>
    </div>
</nav>
<div class="container">
    <div class="container-dashboard">

    <h1 class="mt-4 mb-4">My Profile</h1>
    <div class="card">
        <div class="card-header">
            <h5 class="card-title">Account Information</h5>
        </div>
        <div class="card-body">
            <p><strong>Full Name:</strong> <?php echo htmlspecialchars($user['fullname']); ?></p>
            <p><strong>Role:</strong> <?php echo htmlspecialchars($user['role']); ?></p>
            <p><strong>Username:</strong> <?php echo htmlspecialchars($user['username']); ?></p>
            <p><strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?></p>
        </div>
    </div>
    <!-- Example: Add buttons for account settings, password change, etc. -->
    <div class="mt-4">
        <a href="../php/forgot_password.php" class="btn btn-danger">Change Password</a>
        <a href="../php/staffdashboard.php" class="btn btn-grey">Back</a>
        <!-- Add more buttons or links as per your application's requirements -->
    </div>
</div>
</div>
<footer class="footer mt-5">
    <p>&copy; 2024 RHA Parcel Centre. All Rights Reserved.</p>
    <p>Contact us at <a href="mailto:rhaparcelcentre@gmail.com" class="link">rhaparcelcentre@gmail.com</a></p>
</footer>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
