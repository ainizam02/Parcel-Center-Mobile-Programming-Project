<?php
session_start();
require_once 'db.php'; // Include your database connection

// Function to sanitize input
function sanitize($input) {
    return htmlspecialchars(strip_tags(trim($input)));
}

// Check if parcelId and imageData are set
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['parcelId']) && isset($_POST['imageData'])) {
    // Sanitize inputs
    $parcelId = sanitize($_POST['parcelId']);
    $imageData = $_POST['imageData']; // base64 data does not need sanitization

    // Generate unique filename for the image
    $filename = 'parcel_' . $parcelId . '_' . time() . '.jpg'; // Example: parcel_12345_1627351674.jpg
    
    // Directory where images will be saved
    $uploadDirectory = 'uploads/'; // Create this directory if not exist

    // Ensure the uploads directory exists
    if (!file_exists($uploadDirectory)) {
        if (!mkdir($uploadDirectory, 0777, true) && !is_dir($uploadDirectory)) {
            echo json_encode(['success' => false, 'message' => 'Failed to create upload directory.']);
            exit();
        }
    }
    
    // Save image to server
    $imagePath = $uploadDirectory . $filename;
    $decodedImage = base64_decode(preg_replace('#^data:image/\w+;base64,#i', '', $imageData));

    if ($decodedImage === false) {
        echo json_encode(['success' => false, 'message' => 'Failed to decode image.']);
        exit();
    }

    if (file_put_contents($imagePath, $decodedImage) !== false) {
        // Update database with image path
        $sql = "UPDATE parcels SET image_path = :imagePath WHERE parcel_id = :parcelId";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':imagePath', $imagePath);
        $stmt->bindParam(':parcelId', $parcelId, PDO::PARAM_INT);
        
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Image saved successfully.']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to update database.']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to save image on server.']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request.']);
}
?>
