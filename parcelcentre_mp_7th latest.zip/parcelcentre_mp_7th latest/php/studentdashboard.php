<?php
require_once 'db.php'; // Include your database connection

// Function to sanitize input
function sanitize($input) {
    return htmlspecialchars(strip_tags(trim($input)));
}

// Start session (if not already started)
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    // Redirect to login page or handle unauthorized access
    header("Location: loginindex.php");
    exit;
}

// Get user ID from session
$user_id = $_SESSION['user_id'];

// Initialize the query and parameters
$sql = "SELECT parcel_id, arrival_date, tracking_number, status, image_path FROM parcels WHERE user_id = :user_id";
$params = [':user_id' => $user_id];

// Check if search is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['search_parcel'])) {
    $tracking_number = sanitize($_POST['tracking_number']);
    if (!empty($tracking_number)) {
        $sql .= " AND tracking_number = :tracking_number";
        $params[':tracking_number'] = $tracking_number;
    }
}

// Display all parcels
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['display_all'])) {
    // No additional filter needed for all parcels owned by the user
}

// Prepare and execute the query
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$parcels = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- Bootstrap Icons CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
   
    <style>
        /* Custom Styles */
        body {
            background-color: #fbfcfa;
        }
        .navbar {
            background-color: #2c3e50;
        }
        .navbar-brand,
        .navbar-nav .nav-link {
            color: #F8F3EA !important;
        }
        .navbar-brand img {
            height: 40px; /* Adjust the height as needed */
            margin-right: 10px; /* Space between logo and text */
            border-radius: 50%; /* Make the logo round */
            object-fit: cover; /* Ensure the image fits the container */
        }
        .container-dashboard {
            background-color: #ffcba9;
            padding: 20px;
            border-radius: 10px;
            margin-top: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .container-header {
            background-color: #FF6600;
            color: #FFFFFF;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
        }
        
        .btn-orange {
            background-color: #FF6600;
            color: white;
            border: none;
        }
        .btn-orange:hover {
            background-color: #e65c00;
        }
        .btn-secondary {
            background-color: #6c757d;
            color: white;
            border: none;
        }
        .btn-secondary:hover {
            background-color: #5a6268;
        }
        .table th,
        .table td {
            vertical-align: middle;
        }
        .footer {
            background-color: #2c3e50;
            padding: 20px 0;
            text-align: center;
            color: #FFFFFF;
            margin-top: 40px;
        }
        .link {
            color: #FF6600;
            text-decoration: none;
        }
        .link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light">
    <a class="navbar-brand" href="#" style="color: #F8F3EA;">
        <img src="../image/logo.jpg" alt="Logo">
        RHA Parcel Centre</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ml-auto">
            <li class="nav-item">
                <a class="nav-link" href="../php/studentdashboard.php">Parcels</a>
            </li>
            <!-- User Account Section -->
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle"  href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="bi bi-person-circle"></span>
                     <!-- Replace with actual user name -->
                </a>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                    <a class="dropdown-item" href="../php/studentprofile.php">My Profile</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="../php/loginindex.php">Logout</a>
                </div>
            </li>
        </ul>
    </div>
</nav>
<div class="container mt-5">
    <div class="container-header">
        <h1>Welcome to RHA Parcel Centre</h1>
        <p>Manage your parcels efficiently and effectively.</p>
    </div>
    <div class="container-dashboard">
        <h2>New Parcel Arrived</h2>
        <div class="row mb-4">
            <div class="col-md-12">
                <!-- Display All and Search Forms -->
                <form action="" method="post" class="form-inline mb-4">
                <div class="form-group mx-sm-3 mb-2">
                        <label for="tracking_number" class="sr-only">Tracking Number</label>
                        <input type="text" name="tracking_number" class="form-control" placeholder="Enter Tracking Number">
                    </div>
                    <button type="submit" name="search_parcel" class="btn btn-orange mb-2 mr-2">Search</button>
                    <button type="submit" name="display_all" class="btn btn-primary mb-2">Display All</button>
                </form>
                
                <!-- Notification for no parcel found -->
                <?php if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['search_parcel']) && empty($parcels)): ?>
                    <div class="alert alert-warning" role="alert">
                        Oops! There is no parcel with the tracking number "<?php echo $tracking_number; ?>".
                    </div>
                <?php endif; ?>
                
                <!-- Table to display parcels -->
                <div class="table-responsive">
                    <table class="table table-striped ">
                        <thead>
                            <tr>
                                <th>Parcel ID</th>
                                <th>Arrival Date</th>
                                <th>Tracking Number</th>
                                <th>Status</th>
                                <th>Image</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($parcels as $parcel): ?>
                            <tr>
                                <td><?php echo $parcel['parcel_id']; ?></td>
                                <td><?php echo $parcel['arrival_date']; ?></td>
                                <td><?php echo $parcel['tracking_number']; ?></td>
                                <td><?php echo $parcel['status']; ?></td>
                                <td>
                                    <?php if ($parcel['image_path']): ?>
                                        <img src="<?php echo $parcel['image_path']; ?>" alt="Parcel Image" style="width: 100px; height: auto;">
                                    <?php else: ?>
                                        No Image
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<footer class="footer mt-5">
    <p>&copy; 2024 RHA Parcel Centre. All Rights Reserved.</p>
    <p>Contact us at <a href="mailto:rhaparcelcentre@gmail.com" class="link">rhaparcelcentre@gmail.com</a></p>
</footer>
<!-- Bootstrap JS and jQuery (Optional) -->
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>

<!-- Auto-refreshing the table every 30 seconds -->
<script>
$(document).ready(function() {
    setInterval(function() {
        $.ajax({
            url: 'fetch_parcels.php', // Create this file to fetch the latest parcels data
            method: 'GET',
            success: function(response) {
                $('#parcel-table').html(response);
            }
        });
    }, 30000); // Refresh every 30 seconds
});
</script>

</body>
</html>
