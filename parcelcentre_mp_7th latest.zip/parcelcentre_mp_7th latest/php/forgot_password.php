<!-- forgot_password.php -->
<?php
session_start();
require_once 'db.php';

$username = $new_password = '';
$username_err = $new_password_err = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate Username
    if (empty(trim($_POST["username"]))) {
        $username_err = "Please enter your username or email.";
    } else {
        $username = trim($_POST["username"]);
    }

    // Validate New Password
    if (empty(trim($_POST["new_password"]))) {
        $new_password_err = "Please enter a new password.";
    } elseif (strlen(trim($_POST["new_password"])) < 6) {
        $new_password_err = "Password must have at least 6 characters.";
    } else {
        $new_password = trim($_POST["new_password"]);
    }

    // Check input errors before updating the password
    if (empty($username_err) && empty($new_password_err)) {
        // Prepare an update statement
        $sql = "UPDATE users SET password_hash = :password_hash WHERE username = :username";

        if ($stmt = $pdo->prepare($sql)) {
            // Generate a password hash
            $password_hash = password_hash($new_password, PASSWORD_DEFAULT);

            // Bind variables to the prepared statement as parameters
            $stmt->bindParam(':password_hash', $password_hash, PDO::PARAM_STR);
            $stmt->bindParam(':username', $username, PDO::PARAM_STR);

            // Attempt to execute the prepared statement
            if ($stmt->execute()) {
                // Password updated successfully
                // Redirect to login page or home page
                header("Location: loginindex.php");
                exit();
            } else {
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            unset($stmt);
        }
    }

    // Close connection
    unset($pdo);
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- Custom Styles -->
    <style>
        /* Custom styles */
        body {
        background-color: #fbfcfa;
        }
        .navbar {
            background-color: #2c3e50;
        }
        .navbar-brand,
        .navbar-nav .nav-link {
            color: #F8F3EA !important; /* Bright font color */
        }
        .navbar-brand img {
            height: 40px; /* Adjust the height as needed */
            margin-right: 10px; /* Space between logo and text */
            border-radius: 50%; /* Make the logo round */
            object-fit: cover; /* Ensure the image fits the container */
        }
        .container {
            background-color: #FFFFFF;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .header {
            background-color: #FF6600;
            color: #FFFFFF;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
        }
        .header h1 {
            margin: 0;
            font-size: 2.5rem;
        }
        .pass-section {
            background-color: #f8f8f8;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-top: 20px;
        }
        .footer {
            background-color: #2c3e50;
            padding: 10px 0;
            text-align: center;
            margin-top: 40px;
            color: #FFFFFF;
        }
        .footer .footer-content {
            color: #FFFFFF;
        }
        .btn-primary {
            background-color: #e98d04;
            border: none;
        }
        .btn-primary:hover {
            background-color: #c07504;
        }
        .link {
            color: #FF6600;
            text-decoration: none;
        }
        .link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light">
        <a class="navbar-brand" href="#">
            <img src="../image/logo.jpg" alt="Logo">
            RHA Parcel Centre</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="../php/loginindex.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../html/about.html">About Us</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../html/contact.html">Contact Us</a>
                </li>
            </ul>
        </div>
    </nav>
    <div class="container mt-5">
        <div class="header">
            <h1>Forgot Your Password?</h1>
            <p>Enter your Username or Email Address to reset your password.</p>
        </div>
        <div class="pass-section mt-4">
        <form action="forgot_password.php" method="post">
                <div class="form-group">
                    <label for="username">Username or Email</label>
                    <input type="text" class="form-control" id="username" name="username" required>
                </div>
                <div class="form-group">
                    <label for="new_password">New Password</label>
                    <input type="password" class="form-control" id="new_password" name="new_password" required>
                </div>
                <button type="submit" class="btn btn-primary">Reset Password</button>
            </form>
        </div>
    </div>
    <footer class="footer mt-5">
        <div class="footer-content">
            <p>&copy; 2024 RHA Parcel Centre. All Rights Reserved.</p>
            <p>Contact us at <a href="mailto:rhaparcelcentre@gmail.com" class="link">rhaparcelcentre@gmail.com</a></p>
        </div>
    </footer>
    <!-- Bootstrap JS and jQuery (Optional) -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
</body>
</html>
