<?php
require_once 'db.php'; // Include your database connection

// Function to sanitize input
function sanitize($input) {
    return htmlspecialchars(strip_tags(trim($input)));
}

session_start();

// Add CSRF token for security
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Add new parcel if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_parcel']) && hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
    // Sanitize inputs
    $user_id = sanitize($_POST['user_id']);
    $arrival_date = sanitize($_POST['arrival_date']);
    $tracking_number = sanitize($_POST['tracking_number']);
    $status = sanitize($_POST['status']);

    // Prepare statement to insert parcel
    $sql = "INSERT INTO parcels (user_id, arrival_date, tracking_number, status) VALUES (:user_id, :arrival_date, :tracking_number, :status)";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->bindParam(':arrival_date', $arrival_date);
    $stmt->bindParam(':tracking_number', $tracking_number);
    $stmt->bindParam(':status', $status);

    // Execute statement
    if ($stmt->execute()) {
        // Retrieve the student's email
        $sql = "SELECT email FROM users WHERE user_id = :user_id";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
        $stmt->execute();
        $email = $stmt->fetchColumn();

        if ($email) {
            // Call the mail.js script to send the email
            $message = "Your parcel has arrived. Please collect it from the parcel center.";
            $output = shell_exec("node mail.js " . escapeshellarg($email) . " " . escapeshellarg($message));
            echo "New parcel added successfully. Email sent.";
        } else {
            echo "New parcel added successfully, but email not found.";
        }
    } else {
        echo "Oops! Something went wrong.";
    }
}

// Delete parcel if requested
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['confirm_delete_parcel']) && hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
    $parcel_id = sanitize($_POST['parcel_id']);
    
    // Prepare statement
    $sql = "DELETE FROM parcels WHERE parcel_id = :parcel_id";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':parcel_id', $parcel_id, PDO::PARAM_INT);
    
    // Execute statement
    if ($stmt->execute()) {
        $_SESSION['delete_success'] = true; // Set session variable for success
        header('Location: ' . $_SERVER['PHP_SELF']); // Redirect to avoid resubmission
        exit();
    } else {
        echo "Oops! Something went wrong.";
    }
}

// Update parcel status if requested
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_status']) && hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
    $parcel_id = sanitize($_POST['parcel_id']);
    $status = sanitize($_POST['status']);
    
    // Prepare statement
    $sql = "UPDATE parcels SET status = :status WHERE parcel_id = :parcel_id";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':parcel_id', $parcel_id, PDO::PARAM_INT);
    $stmt->bindParam(':status', $status);
    
    // Execute statement
    if ($stmt->execute()) {
        $_SESSION['update_success'] = true; // Set session variable for success
        header('Location: ' . $_SERVER['PHP_SELF']); // Redirect to avoid resubmission
        exit();
    } else {
        echo "Oops! Something went wrong.";
    }
}

// Delete image if requested
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_image']) && hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
    $parcel_id = sanitize($_POST['parcel_id']);
    
    // Prepare statement to set image_path to NULL
    $sql = "UPDATE parcels SET image_path = NULL WHERE parcel_id = :parcel_id";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':parcel_id', $parcel_id, PDO::PARAM_INT);
    
    // Execute statement
    if ($stmt->execute()) {
        $_SESSION['image_delete_success'] = true; // Set session variable for success
        header('Location: ' . $_SERVER['PHP_SELF']); // Redirect to avoid resubmission
        exit();
    } else {
        echo "Oops! Something went wrong.";
    }
}

// Query to fetch all parcels
$sql = "SELECT parcel_id, user_id, arrival_date, tracking_number, status, image_path FROM parcels";
$stmt = $pdo->query($sql);
$parcels = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Query to fetch all students
$sql = "SELECT user_id, fullname FROM users WHERE role = 'student'";
$stmt = $pdo->query($sql);
$students = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Dashboard</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- Bootstrap Icons CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/styles.css"> <!-- External CSS -->
    <link rel="stylesheet" href="../css/staffdashboard.css"> 
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light">
    <a class="navbar-brand" href="#" style="color: #F8F3EA;">
    <img src="../image/logo.jpg" alt="Logo">
    RHA Parcel Centre</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ml-auto">
            <li class="nav-item">
                <a class="nav-link" href="../php/add_parcel.php">Manage Parcels</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="../php/staffdashboard.php">Parcel Information</a>
            </li>
            <!-- User Account Section -->
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle"  href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="bi bi-person-circle"></span>
                     <!-- Replace with actual user name -->
                </a>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                    <a class="dropdown-item" href="../php/staffprofile.php">My Profile</a>
                    <div class="dropdown-divider"></div>
                    <a class="dropdown-item" href="../php/loginindex.php">Logout</a>
                </div>
            </li>
        </ul>
    </div>
</nav>
<br><br>
<div class="container">
    <div class="container-header">
        <h1>Parcel Information Management</h1>
        <p>Please update the parcels information.</p>
    </div>
</div>

<div class="container">
    <div class="container-dashboard">
        <div class="row">
            <h2>Parcel Information</h2>
        </div>
        <div class="row">
            <div class="col-md-12">
                <!-- Add table-responsive class here -->
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Parcel ID</th>
                                <th>User ID</th>
                                <th>Arrival Date</th>
                                <th>Tracking Number</th>
                                <th>Parcel Status</th>
                                <th>Image</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($parcels as $parcel): ?>
                            <tr>
                                <td><?php echo $parcel['parcel_id']; ?></td>
                                <td><?php echo $parcel['user_id']; ?></td>
                                <td><?php echo $parcel['arrival_date']; ?></td>
                                <td><?php echo $parcel['tracking_number']; ?></td>
                                <td>
    <form class="status-form" method="post">
        <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
        <input type="hidden" name="parcel_id" value="<?php echo $parcel['parcel_id']; ?>">
        <input type="hidden" name="update_status" value="1">
        <select name="status" class="form-select" onchange="this.form.submit()">
            <option value="Picked Up" <?php if ($parcel['status'] == 'Picked Up') echo 'selected'; ?>>Picked Up</option>
            <option value="Not Picked Up" <?php if ($parcel['status'] == 'Not Picked Up') echo 'selected'; ?>>Not Picked Up</option>
        </select>
    </form>
</td>

                                <td>
                                    <?php if ($parcel['image_path']): ?>
                                        <img src="<?php echo $parcel['image_path']; ?>" alt="Parcel Image" style="width: 100px; height: auto;">
                                        <form action="" method="post" style="display: inline;">
                                            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                                            <input type="hidden" name="parcel_id" value="<?php echo $parcel['parcel_id']; ?>">
                                            <button type="submit" name="delete_image" class="btn btn-warning">Delete Image</button>
                                        </form>
                                    <?php else: ?>
                                        No Image
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <form action="" method="post" style="display: inline;">
                                        <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                                        <input type="hidden" name="parcel_id" value="<?php echo $parcel['parcel_id']; ?>">
                                        <button type="submit" name="confirm_delete_parcel" class="btn btn-danger">Delete</button>
                                    </form>
                                    <button class="btn btn-primary" onclick="openCamera(<?php echo $parcel['parcel_id']; ?>)">Capture Photo</button>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div> <!-- End of table-responsive div -->
            </div>
        </div>
    </div>
</div>


<!-- Camera Modal -->
<div id="cameraModal" class="modal fade" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Capture Photo</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <video id="video" width="100%" autoplay></video>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" onclick="savePhoto()">Capture Photo</button>
            </div>
        </div>
    </div>
</div>
<footer class="footer mt-5">
        <p>&copy; 2024 RHA Parcel Centre. All Rights Reserved.</p>
        <p>Contact us at <a href="mailto:rhaparcelcentre@gmail.com" class="link">rhaparcelcentre@gmail.com</a></p>
</footer>
<!-- jQuery and Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<script>
var $j = jQuery.noConflict(); // Avoid conflicts with other libraries

var parcelId; // Global variable to hold the current parcel ID

function openCamera(id) {
    parcelId = id; // Set the global parcelId variable
    $j('#cameraModal').modal('show'); // Show the camera modal
    startCamera(); // Start the camera feed
}

function startCamera() {
    navigator.mediaDevices.getUserMedia({ video: true })
        .then(function (stream) {
            var video = document.getElementById('video');
            video.srcObject = stream;
            video.play();
        })
        .catch(function (err) {
            console.log("An error occurred: " + err);
        });
}

function savePhoto() {
    var canvas = document.createElement('canvas');
    var video = document.getElementById('video');
    var context = canvas.getContext('2d');
    
    // Set canvas dimensions to match video feed
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    
    // Draw current frame from video onto the canvas
    context.drawImage(video, 0, 0, canvas.width, canvas.height);
    
    // Convert canvas image to base64-encoded JPEG
    var imgData = canvas.toDataURL('image/jpeg');
    
    // AJAX to save the image via PHP endpoint
    $j.ajax({
        type: 'POST',
        url: 'save-image-endpoint.php', // PHP script to handle image saving
        data: {
            parcelId: parcelId, // Use the global variable to identify which parcel the image belongs to
            imageData: imgData // Base64-encoded JPEG image data
        },
        success: function (response) {
            var res = JSON.parse(response);
            if (res.success) {
                console.log('Image saved successfully');
                $j('#cameraModal').modal('hide'); // Hide the modal after successful image capture
                updateTable(parcelId, imgData); // Update the table with the new image
                toggleDeleteImageButton(parcelId, true); // Show the delete image button
            } else {
                console.error('Error saving image:', res.message);
            }
        },
        error: function (error) {
            console.error('Error saving image:', error);
            $j('#cameraModal').modal('hide'); // Hide the modal on error
        }
    });
}

function updateTable(parcelId, imgData) {
    // Find the table row corresponding to the parcelId
    var row = $j('tr').filter(function () {
        return $j(this).find('td:first').text() == parcelId;
    });

    // Update the image cell in the found row
    row.find('td:eq(5)').html('<img src="' + imgData + '" alt="Parcel Image" style="width: 100px; height: auto;">');
}

function toggleDeleteImageButton(parcelId, show) {
    var deleteButton = $j('input[name="parcel_id"][value="' + parcelId + '"]').siblings('button[name="delete_image"]');
    if (show) {
        deleteButton.show(); // Show the delete image button
    } else {
        deleteButton.hide(); // Hide the delete image button
    }
}
</script>
</body>
</html>
