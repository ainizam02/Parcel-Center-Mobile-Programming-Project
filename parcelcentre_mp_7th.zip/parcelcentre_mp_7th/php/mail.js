const nodemailer = require('nodemailer');
const { google } = require('googleapis');

const CLIENT_ID = '940104823008-1ffi4qs0n8uifju87inu0jbsjiuj3mlv.apps.googleusercontent.com';
const CLIENT_SECRET = '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';
const REDIRECT_URI = 'https://developers.google.com/oauthplayground';
const REFRESH_TOKEN = '1//04MTp-VTEod4FCgYIARAAGAQSNwF-L9IrdMdTxFPr7KqcWc6FA71HYk6RZaoUuQGaNWa7SrsMBiHkRqVi0qzSt20NBFQkbAI1DEk';

const oAuth2Client = new google.auth.OAuth2(CLIENT_ID, CLIENT_SECRET, REDIRECT_URI);
oAuth2Client.setCredentials({ refresh_token: REFRESH_TOKEN });

async function sendMail(recipientEmail, message) {
    try {
        const accessToken = await oAuth2Client.getAccessToken();
        console.log('Access Token:', accessToken);

        const transport = nodemailer.createTransport({
            service: 'gmail',
            auth: {
                type: 'OAuth2',
                user: 'rhaparcelcentre@gmail.com',
                clientId: CLIENT_ID,
                clientSecret: CLIENT_SECRET,
                refreshToken: REFRESH_TOKEN,
                accessToken: accessToken.token
            }
        });

        const mailOptions = {
            from: 'rhaparcelcentre@gmail.com',
            to: recipientEmail,
            subject: 'Parcel Notification',
            text: message,
            html: `<p>${message}</p>`
        };

        const result = await transport.sendMail(mailOptions);
        console.log('Email sent...', result);
        return result;
    } catch (error) {
        console.error('Error sending email:', error.message);
        return error;
    }
}

const recipientEmail = process.argv[2];
const message = process.argv[3];
sendMail(recipientEmail, message).then(result => console.log('Email sent...', result))
.catch(error => console.log(error.message));