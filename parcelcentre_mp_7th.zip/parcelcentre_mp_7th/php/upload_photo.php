<?php
require_once 'db.php'; // Include your database connection

// Function to sanitize input
function sanitize($input) {
    return htmlspecialchars(strip_tags(trim($input)));
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['parcel_id']) && isset($_POST['image_data'])) {
    $parcel_id = sanitize($_POST['parcel_id']);
    $image_data = $_POST['image_data'];

    // Decode the image data and save it as a file
    $image_data = str_replace('data:image/png;base64,', '', $image_data);
    $image_data = str_replace(' ', '+', $image_data);
    $image_content = base64_decode($image_data);
    $image_path = 'uploads/parcel_' . $parcel_id . '.png';

    if (file_put_contents($image_path, $image_content)) {
        // Update the database with the image path
        $sql = "UPDATE parcels SET image_path = :image_path WHERE parcel_id = :parcel_id";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':image_path', $image_path);
        $stmt->bindParam(':parcel_id', $parcel_id, PDO::PARAM_INT);

        if ($stmt->execute()) {
            echo "Photo uploaded and parcel updated successfully.";
        } else {
            echo "Oops! Something went wrong.";
        }
    } else {
        echo "Failed to save the photo.";
    }
} else {
    echo "Invalid request.";
}
?>
